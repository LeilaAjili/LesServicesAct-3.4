<?php

namespace AppBundle\Service;

use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Finder\Finder;


class FileSystemImproved 

{

    public function __construct()

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        try {

            $new_dir_path = $current_dir_path . "/fsi";

            if (!$fsObject->exists($new_dir_path)) {

                $fsObject->mkdir($new_dir_path, 0775);
            }

        } catch (IOExceptionInterface $exception) {

            echo "Error creating directory at" . $exception->getPath();

        }

    }


    public function getFiles()

    {
        $current_dir_path = getcwd();

        $dir_path = $current_dir_path."/fsi";

        $finder = new Finder();

        $finder->files()->in($dir_path);

        foreach ($finder as $file) 
        
        {
            var_dump($file->getFilename());

            var_dump($file->getRealPath());
  
        }

    }

    public function createFile($fileName)

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        $dir_path = $current_dir_path."/fsi";

        try {
            $new_file_path = $dir_path . "/$fileName.txt";
        
            if (!$fsObject->exists($new_file_path))
            {
                $fsObject->touch($new_file_path);

                $fsObject->chmod($new_file_path, 0777);
               
            }
        } catch (IOExceptionInterface $exception) {
            echo "Error creating file at". $exception->getPath();
        }

       
    }

    public function deleteFile($fileName)

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        $dir_path = $current_dir_path."/fsi";

        $fileToDelete = $dir_path ."/$fileName.txt";

        if (!$fsObject->exists($fileToDelete))

        return false;

        else

        { 
            $fsObject->remove($fileToDelete);
            
            return true;
        }

    }

    public function getFile($fileName)

    {

        $finder = new Finder();

        $current_dir_path = getcwd();

        $dir_path = $current_dir_path."/fsi";

        $finder->files()->name($fileName);
        
        foreach ($finder as $file) {
            $contents = $file->getContents();
        
            // ...
        }
        return $contents;




    }
    




    public function writeInFile()

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        $file_path = $current_dir_path."/fsi/history.txt";

        $fsObject->appendToFile($file_path, "Dispatched event!\n");


    }

    public function writeInLog($message)

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        $file_path = $current_dir_path."/fsi/log.txt";

        $fsObject->appendToFile($file_path, $message."\n");

    }




}
