<?php
namespace AppBundle\Event;

use Symfony\Component\EventDispatcher\Event;
use AppBundle\Service\FileSystemImproved;

class FileCreatedEvent extends Event

{

    /**
     * @var FileSystemImproved $_FileSystemImproved
     */

    private $fileSystemImproved;

    const NAME = "File_Created";

    public function __construct(FileSystemImproved $fileSystemImproved)

    {

        $this->fileSystemImproved = $fileSystemImproved;

    }

    
}