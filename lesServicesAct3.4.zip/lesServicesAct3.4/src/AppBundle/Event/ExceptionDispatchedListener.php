<?php

namespace AppBundle\Event;


use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\HttpKernel\Event\GetResponseForExceptionEvent;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Service\FileSystemImproved;


class ExceptionDispatchedListener

{

    public function onKernelException(GetResponseForExceptionEvent $event)

    {

       $exception =  $event->getException();

       $message = sprintf('My Error says: %s with code %s',$exception->getMessage(),$exception->getCode());

       $response = new Response();

       $response->setContent($message);

       if($exception instanceof HttpExceptionInterface){

           $response->setStatusCode($exception->getStatusCode());

           $response->headers->replace($exception->getHeaders());

       }

       else

       {

           $response->setStatusCode(Response::HTTP_INTERNAL_SERVER_ERROR);
       }

       $fileSystemImproved = new FileSystemImproved();

       $fileSystemImproved->writeInLog(new Response("Something wrong!"));

      // $event->setResponse(new Response("Something wrong!"));

       $event->stopPropagation();

       

    }
}