<?php

namespace AppBundle\Event;

use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use AppBundle\Service\FileSystemImproved;

class FileCreatedSubscriber implements EventSubscriberInterface

{

    public static function getSubscribedEvents()

    {
        return [FileCreatedEvent::NAME => 'onFileCreated'];
    }

    public function onFileCreated(FileCreatedEvent $event)

    {

        //dump ($event);

        $file = new FileSystemImproved();

        $file->writeInFile();

    }


}