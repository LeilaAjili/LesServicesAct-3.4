<?php

namespace AppBundle\Controller;

use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Service\FileSystemImproved;
use Symfony\Component\HttpFoundation\Request;


class FileController extends Controller

{

    /**
     * @Route("/create/{fileName}", name="createFile")
     */
    public function createFile($fileName)
    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        try {
            $new_file_path = $current_dir_path . "/$fileName.txt";
        
            if (!$fsObject->exists($new_file_path))

            {
                $fsObject->touch($new_file_path);

                $fsObject->chmod($new_file_path, 0777);
               
            }
        } catch (IOExceptionInterface $exception) {
            echo "Error creating file at". $exception->getPath();
        }

        return new Response('<html><body>OK</body></html>');

    }


    /**
     * @Route("/write/{file}/{text}", name="writeInFile")
     */
    public function writeInFile($file, $text)

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        $file_path = $current_dir_path . "/$file.txt";

        $fsObject->dumpFile($file_path, 70, "$text.\n");

        return new Response('<html><body>OK</body></html>');


    }

    /**
     * @Route("/copy/{from}/{to}", name="copyFile")
     */
    public function copyFile($from, $to)

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        $fromFile = $current_dir_path ."/$from.txt";

        $toFile = $current_dir_path ."/$to.txt";

            if ($fsObject->exists($fromFile))

            {
                $fsObject->copy($fromFile, $toFile);

                return new Response('<html><body>OK FOR COPY</body></html>');

            }

            else

            return new Response('<html><body>NOT OK FOR COPY</body></html>');
    
    }

    /**
     * @Route("/delete/{fileName}", name="deleteFile")
     */
    public function deleteFile($fileName)

    {

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        $fileToDelete = $current_dir_path ."/$fileName.txt";

        $fsObject->remove($fileToDelete);

        return new Response('<html><body>OK FOR DELETE</body></html>');

    }


   /**
     * @Route("/service")
     */

     public function service()

     {

      $FileSystemImproved = new FileSystemImproved();

       return new Response('<html><body>service</body></html>');

     }


     /**
     * @Route("/getFiles")
     */

    public function getFiles()

    {

     $FileSystemImproved = new FileSystemImproved();

     $response = new Response(json_encode( $FileSystemImproved->getFiles()));

     $response->headers->set('Content-Type', 'application/json');

    return $response;

    }

    /**
     * @Route("/createNewFile/{fileName}")
     */

    public function createNewFile($fileName)

    {

     $FileSystemImproved = new FileSystemImproved();

     $FileSystemImproved->createFile($fileName);

     $response = new Response(json_encode( $FileSystemImproved->getFiles()));

     $response->headers->set('Content-Type', 'application/json');

    return $response;

    }

    /**
     * @Route("/deleteNewFile/{fileName}")
     */

    public function deleteNewFile($fileName)

    {

     $FileSystemImproved = new FileSystemImproved();

     

    

     return new Response(var_dump($FileSystemImproved->deleteFile($fileName)));
    }


}