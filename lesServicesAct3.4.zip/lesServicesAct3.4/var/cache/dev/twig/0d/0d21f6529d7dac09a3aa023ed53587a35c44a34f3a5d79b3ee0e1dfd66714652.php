<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_b549632acf015d162fb61593e0530139ac2730a4642372bdb7d60c6e3d7cbb7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a8364e57a62445b8b2fe1d7b2e89783f6d6ae0c25cae6d06d8bf4a3c1506db6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a8364e57a62445b8b2fe1d7b2e89783f6d6ae0c25cae6d06d8bf4a3c1506db6->enter($__internal_0a8364e57a62445b8b2fe1d7b2e89783f6d6ae0c25cae6d06d8bf4a3c1506db6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_02c218e2763f22a9a338e80ebfaf765a4ed9028cf0fc14dbeec50e4d301a4c4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02c218e2763f22a9a338e80ebfaf765a4ed9028cf0fc14dbeec50e4d301a4c4a->enter($__internal_02c218e2763f22a9a338e80ebfaf765a4ed9028cf0fc14dbeec50e4d301a4c4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_0a8364e57a62445b8b2fe1d7b2e89783f6d6ae0c25cae6d06d8bf4a3c1506db6->leave($__internal_0a8364e57a62445b8b2fe1d7b2e89783f6d6ae0c25cae6d06d8bf4a3c1506db6_prof);

        
        $__internal_02c218e2763f22a9a338e80ebfaf765a4ed9028cf0fc14dbeec50e4d301a4c4a->leave($__internal_02c218e2763f22a9a338e80ebfaf765a4ed9028cf0fc14dbeec50e4d301a4c4a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
