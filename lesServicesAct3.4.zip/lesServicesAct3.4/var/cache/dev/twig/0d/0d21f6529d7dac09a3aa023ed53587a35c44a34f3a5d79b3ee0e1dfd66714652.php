<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_b549632acf015d162fb61593e0530139ac2730a4642372bdb7d60c6e3d7cbb7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d07fc5a3ebe535261a85c64af23158ccd365ede72c9256d9fcae30b642b9ad4b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d07fc5a3ebe535261a85c64af23158ccd365ede72c9256d9fcae30b642b9ad4b->enter($__internal_d07fc5a3ebe535261a85c64af23158ccd365ede72c9256d9fcae30b642b9ad4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_f4c4c498edc507fca49fe7092f326c34e5114a551ab51886fdf8ede993527e32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4c4c498edc507fca49fe7092f326c34e5114a551ab51886fdf8ede993527e32->enter($__internal_f4c4c498edc507fca49fe7092f326c34e5114a551ab51886fdf8ede993527e32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_d07fc5a3ebe535261a85c64af23158ccd365ede72c9256d9fcae30b642b9ad4b->leave($__internal_d07fc5a3ebe535261a85c64af23158ccd365ede72c9256d9fcae30b642b9ad4b_prof);

        
        $__internal_f4c4c498edc507fca49fe7092f326c34e5114a551ab51886fdf8ede993527e32->leave($__internal_f4c4c498edc507fca49fe7092f326c34e5114a551ab51886fdf8ede993527e32_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
