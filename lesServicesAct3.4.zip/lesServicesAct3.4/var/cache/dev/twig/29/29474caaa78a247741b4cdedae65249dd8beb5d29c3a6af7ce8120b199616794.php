<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_2a53bc253a0b4816d6894cf7a3fb288f9368a4ad6f2639f7d55629ac07c7171e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35e9eef4ad3d71449d982afa7bba2dab7bf0afd31696f223c9673f33c1d8bdff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35e9eef4ad3d71449d982afa7bba2dab7bf0afd31696f223c9673f33c1d8bdff->enter($__internal_35e9eef4ad3d71449d982afa7bba2dab7bf0afd31696f223c9673f33c1d8bdff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_d47d778192a7e9fb2f9a4b5257bd6dace4eaacfba1d1f28320b90331fdba6a75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d47d778192a7e9fb2f9a4b5257bd6dace4eaacfba1d1f28320b90331fdba6a75->enter($__internal_d47d778192a7e9fb2f9a4b5257bd6dace4eaacfba1d1f28320b90331fdba6a75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_35e9eef4ad3d71449d982afa7bba2dab7bf0afd31696f223c9673f33c1d8bdff->leave($__internal_35e9eef4ad3d71449d982afa7bba2dab7bf0afd31696f223c9673f33c1d8bdff_prof);

        
        $__internal_d47d778192a7e9fb2f9a4b5257bd6dace4eaacfba1d1f28320b90331fdba6a75->leave($__internal_d47d778192a7e9fb2f9a4b5257bd6dace4eaacfba1d1f28320b90331fdba6a75_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_2b2ee03dfe788e8692f68c6563d6befb49167c8a379c4000405424dcbeb64da2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b2ee03dfe788e8692f68c6563d6befb49167c8a379c4000405424dcbeb64da2->enter($__internal_2b2ee03dfe788e8692f68c6563d6befb49167c8a379c4000405424dcbeb64da2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_fcf1a969421236156a8aba4b2288ed9ec693f9e0590698d17e042f3222d2bc8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fcf1a969421236156a8aba4b2288ed9ec693f9e0590698d17e042f3222d2bc8e->enter($__internal_fcf1a969421236156a8aba4b2288ed9ec693f9e0590698d17e042f3222d2bc8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_fcf1a969421236156a8aba4b2288ed9ec693f9e0590698d17e042f3222d2bc8e->leave($__internal_fcf1a969421236156a8aba4b2288ed9ec693f9e0590698d17e042f3222d2bc8e_prof);

        
        $__internal_2b2ee03dfe788e8692f68c6563d6befb49167c8a379c4000405424dcbeb64da2->leave($__internal_2b2ee03dfe788e8692f68c6563d6befb49167c8a379c4000405424dcbeb64da2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
