<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_2a53bc253a0b4816d6894cf7a3fb288f9368a4ad6f2639f7d55629ac07c7171e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8c054a55b795f8fbca59e4ed11a757fc373490a27d9c516e3e527e485bf553b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8c054a55b795f8fbca59e4ed11a757fc373490a27d9c516e3e527e485bf553b->enter($__internal_b8c054a55b795f8fbca59e4ed11a757fc373490a27d9c516e3e527e485bf553b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_2dab01784eba14df454f60ec38f80e4db8481d1989e3317b0574c99f66cafeee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2dab01784eba14df454f60ec38f80e4db8481d1989e3317b0574c99f66cafeee->enter($__internal_2dab01784eba14df454f60ec38f80e4db8481d1989e3317b0574c99f66cafeee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_b8c054a55b795f8fbca59e4ed11a757fc373490a27d9c516e3e527e485bf553b->leave($__internal_b8c054a55b795f8fbca59e4ed11a757fc373490a27d9c516e3e527e485bf553b_prof);

        
        $__internal_2dab01784eba14df454f60ec38f80e4db8481d1989e3317b0574c99f66cafeee->leave($__internal_2dab01784eba14df454f60ec38f80e4db8481d1989e3317b0574c99f66cafeee_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_2da0f38c2f817431c2ad71a373fd34c0b8558bcc09a4f57a8f06e557d9b7f988 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2da0f38c2f817431c2ad71a373fd34c0b8558bcc09a4f57a8f06e557d9b7f988->enter($__internal_2da0f38c2f817431c2ad71a373fd34c0b8558bcc09a4f57a8f06e557d9b7f988_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_fd500885e1210be46b948da3c8cec0475d9d742daa4866eb9a8de0832335ef82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd500885e1210be46b948da3c8cec0475d9d742daa4866eb9a8de0832335ef82->enter($__internal_fd500885e1210be46b948da3c8cec0475d9d742daa4866eb9a8de0832335ef82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_fd500885e1210be46b948da3c8cec0475d9d742daa4866eb9a8de0832335ef82->leave($__internal_fd500885e1210be46b948da3c8cec0475d9d742daa4866eb9a8de0832335ef82_prof);

        
        $__internal_2da0f38c2f817431c2ad71a373fd34c0b8558bcc09a4f57a8f06e557d9b7f988->leave($__internal_2da0f38c2f817431c2ad71a373fd34c0b8558bcc09a4f57a8f06e557d9b7f988_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
