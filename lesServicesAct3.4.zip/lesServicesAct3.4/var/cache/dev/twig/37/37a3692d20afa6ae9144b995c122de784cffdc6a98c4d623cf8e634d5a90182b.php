<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_3f67232da97bd6186c3c0068372e5df065d17fb0f6f1e7e380d7be4d53204bba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2489d5336ffc6a28015712b8ec87627ea452b3d1cb4cf7ad5098ef36f9053906 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2489d5336ffc6a28015712b8ec87627ea452b3d1cb4cf7ad5098ef36f9053906->enter($__internal_2489d5336ffc6a28015712b8ec87627ea452b3d1cb4cf7ad5098ef36f9053906_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_8ec57bf5d9c5946611646e98c66db6c7141d4000ea9684d1386ff1f2969e54ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ec57bf5d9c5946611646e98c66db6c7141d4000ea9684d1386ff1f2969e54ff->enter($__internal_8ec57bf5d9c5946611646e98c66db6c7141d4000ea9684d1386ff1f2969e54ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_2489d5336ffc6a28015712b8ec87627ea452b3d1cb4cf7ad5098ef36f9053906->leave($__internal_2489d5336ffc6a28015712b8ec87627ea452b3d1cb4cf7ad5098ef36f9053906_prof);

        
        $__internal_8ec57bf5d9c5946611646e98c66db6c7141d4000ea9684d1386ff1f2969e54ff->leave($__internal_8ec57bf5d9c5946611646e98c66db6c7141d4000ea9684d1386ff1f2969e54ff_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_compound.html.php");
    }
}
