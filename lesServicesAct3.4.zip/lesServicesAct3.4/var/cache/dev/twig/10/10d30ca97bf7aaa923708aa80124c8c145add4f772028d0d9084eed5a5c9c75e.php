<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0a49730a4415c52dbae0bde59acb7a1499983a905e405c913fd1a90537bf38c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10f96dcf7526ee1cac58f8c8d8493af66a00a90f19fd7679df439b05d4bd9fdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10f96dcf7526ee1cac58f8c8d8493af66a00a90f19fd7679df439b05d4bd9fdd->enter($__internal_10f96dcf7526ee1cac58f8c8d8493af66a00a90f19fd7679df439b05d4bd9fdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_27754698d639cff0b0d1b30f23208ebd934d1b44983603a519ee4dcba7ed8cb3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27754698d639cff0b0d1b30f23208ebd934d1b44983603a519ee4dcba7ed8cb3->enter($__internal_27754698d639cff0b0d1b30f23208ebd934d1b44983603a519ee4dcba7ed8cb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_10f96dcf7526ee1cac58f8c8d8493af66a00a90f19fd7679df439b05d4bd9fdd->leave($__internal_10f96dcf7526ee1cac58f8c8d8493af66a00a90f19fd7679df439b05d4bd9fdd_prof);

        
        $__internal_27754698d639cff0b0d1b30f23208ebd934d1b44983603a519ee4dcba7ed8cb3->leave($__internal_27754698d639cff0b0d1b30f23208ebd934d1b44983603a519ee4dcba7ed8cb3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_58979a796085fee4f499add6ba072c3d1996db6661fe8ff5aad9f63c6a3fba76 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_58979a796085fee4f499add6ba072c3d1996db6661fe8ff5aad9f63c6a3fba76->enter($__internal_58979a796085fee4f499add6ba072c3d1996db6661fe8ff5aad9f63c6a3fba76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_6623a77c66076f9e266250e4be64d2c9c35177bd95090301418f408393af2686 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6623a77c66076f9e266250e4be64d2c9c35177bd95090301418f408393af2686->enter($__internal_6623a77c66076f9e266250e4be64d2c9c35177bd95090301418f408393af2686_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_6623a77c66076f9e266250e4be64d2c9c35177bd95090301418f408393af2686->leave($__internal_6623a77c66076f9e266250e4be64d2c9c35177bd95090301418f408393af2686_prof);

        
        $__internal_58979a796085fee4f499add6ba072c3d1996db6661fe8ff5aad9f63c6a3fba76->leave($__internal_58979a796085fee4f499add6ba072c3d1996db6661fe8ff5aad9f63c6a3fba76_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5e2391967d1963e094689c63e641b6bce939d01d5bb71930dcb305fe1600df18 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e2391967d1963e094689c63e641b6bce939d01d5bb71930dcb305fe1600df18->enter($__internal_5e2391967d1963e094689c63e641b6bce939d01d5bb71930dcb305fe1600df18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0aa3ac4f5d38a7e2cb92c30c7e7c911b4828df5effe87a458adc1a4951b0231a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0aa3ac4f5d38a7e2cb92c30c7e7c911b4828df5effe87a458adc1a4951b0231a->enter($__internal_0aa3ac4f5d38a7e2cb92c30c7e7c911b4828df5effe87a458adc1a4951b0231a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0aa3ac4f5d38a7e2cb92c30c7e7c911b4828df5effe87a458adc1a4951b0231a->leave($__internal_0aa3ac4f5d38a7e2cb92c30c7e7c911b4828df5effe87a458adc1a4951b0231a_prof);

        
        $__internal_5e2391967d1963e094689c63e641b6bce939d01d5bb71930dcb305fe1600df18->leave($__internal_5e2391967d1963e094689c63e641b6bce939d01d5bb71930dcb305fe1600df18_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_9bacad4e062c3013d6b9cedd1bb64342194ced68891bd49b3096125af5b0666e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9bacad4e062c3013d6b9cedd1bb64342194ced68891bd49b3096125af5b0666e->enter($__internal_9bacad4e062c3013d6b9cedd1bb64342194ced68891bd49b3096125af5b0666e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_111d669c15761923f6f6492a69982efd769b17ba28f144f00445ba58aabc5f53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_111d669c15761923f6f6492a69982efd769b17ba28f144f00445ba58aabc5f53->enter($__internal_111d669c15761923f6f6492a69982efd769b17ba28f144f00445ba58aabc5f53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_111d669c15761923f6f6492a69982efd769b17ba28f144f00445ba58aabc5f53->leave($__internal_111d669c15761923f6f6492a69982efd769b17ba28f144f00445ba58aabc5f53_prof);

        
        $__internal_9bacad4e062c3013d6b9cedd1bb64342194ced68891bd49b3096125af5b0666e->leave($__internal_9bacad4e062c3013d6b9cedd1bb64342194ced68891bd49b3096125af5b0666e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
