<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0a49730a4415c52dbae0bde59acb7a1499983a905e405c913fd1a90537bf38c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2304d9a4e5d6bf4a09d9e94a70c72702fcd434c8b26f71c09b236b4560bca487 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2304d9a4e5d6bf4a09d9e94a70c72702fcd434c8b26f71c09b236b4560bca487->enter($__internal_2304d9a4e5d6bf4a09d9e94a70c72702fcd434c8b26f71c09b236b4560bca487_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_6b9e426b32848e37ea2565b84af0e9b3d6e2e807094896735270498ba935f058 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b9e426b32848e37ea2565b84af0e9b3d6e2e807094896735270498ba935f058->enter($__internal_6b9e426b32848e37ea2565b84af0e9b3d6e2e807094896735270498ba935f058_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2304d9a4e5d6bf4a09d9e94a70c72702fcd434c8b26f71c09b236b4560bca487->leave($__internal_2304d9a4e5d6bf4a09d9e94a70c72702fcd434c8b26f71c09b236b4560bca487_prof);

        
        $__internal_6b9e426b32848e37ea2565b84af0e9b3d6e2e807094896735270498ba935f058->leave($__internal_6b9e426b32848e37ea2565b84af0e9b3d6e2e807094896735270498ba935f058_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_8e18dd588ec56f2f10c884e00b99ad8037298ea15c642035e8c6f525920b995f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e18dd588ec56f2f10c884e00b99ad8037298ea15c642035e8c6f525920b995f->enter($__internal_8e18dd588ec56f2f10c884e00b99ad8037298ea15c642035e8c6f525920b995f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f720b76052f9c9738f785011067188e3ff293b8d5a375f10d73c8584edee32c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f720b76052f9c9738f785011067188e3ff293b8d5a375f10d73c8584edee32c5->enter($__internal_f720b76052f9c9738f785011067188e3ff293b8d5a375f10d73c8584edee32c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f720b76052f9c9738f785011067188e3ff293b8d5a375f10d73c8584edee32c5->leave($__internal_f720b76052f9c9738f785011067188e3ff293b8d5a375f10d73c8584edee32c5_prof);

        
        $__internal_8e18dd588ec56f2f10c884e00b99ad8037298ea15c642035e8c6f525920b995f->leave($__internal_8e18dd588ec56f2f10c884e00b99ad8037298ea15c642035e8c6f525920b995f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_fe43de9bf28936058e782cc09355bdf12d63652b56416501194da4a83a98c716 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe43de9bf28936058e782cc09355bdf12d63652b56416501194da4a83a98c716->enter($__internal_fe43de9bf28936058e782cc09355bdf12d63652b56416501194da4a83a98c716_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_f998ad0ee76b21a75e36bff4b01908d26b89c202b2f1537e84986db758f9c816 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f998ad0ee76b21a75e36bff4b01908d26b89c202b2f1537e84986db758f9c816->enter($__internal_f998ad0ee76b21a75e36bff4b01908d26b89c202b2f1537e84986db758f9c816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_f998ad0ee76b21a75e36bff4b01908d26b89c202b2f1537e84986db758f9c816->leave($__internal_f998ad0ee76b21a75e36bff4b01908d26b89c202b2f1537e84986db758f9c816_prof);

        
        $__internal_fe43de9bf28936058e782cc09355bdf12d63652b56416501194da4a83a98c716->leave($__internal_fe43de9bf28936058e782cc09355bdf12d63652b56416501194da4a83a98c716_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_052f311520a1574c44b9fc9686817ee0db9a8df1badd39d3ac2c48a3fd78b22c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_052f311520a1574c44b9fc9686817ee0db9a8df1badd39d3ac2c48a3fd78b22c->enter($__internal_052f311520a1574c44b9fc9686817ee0db9a8df1badd39d3ac2c48a3fd78b22c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_8ed9ed59558264fd4ac7a3916c45a9fe5db5bfd98e102e798c75afb129757bea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ed9ed59558264fd4ac7a3916c45a9fe5db5bfd98e102e798c75afb129757bea->enter($__internal_8ed9ed59558264fd4ac7a3916c45a9fe5db5bfd98e102e798c75afb129757bea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_8ed9ed59558264fd4ac7a3916c45a9fe5db5bfd98e102e798c75afb129757bea->leave($__internal_8ed9ed59558264fd4ac7a3916c45a9fe5db5bfd98e102e798c75afb129757bea_prof);

        
        $__internal_052f311520a1574c44b9fc9686817ee0db9a8df1badd39d3ac2c48a3fd78b22c->leave($__internal_052f311520a1574c44b9fc9686817ee0db9a8df1badd39d3ac2c48a3fd78b22c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
