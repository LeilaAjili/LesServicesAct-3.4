<?php

/* @Twig/Exception/error.txt.twig */
class __TwigTemplate_8fd8da705ec710cdd9a7c5296b23d451a31921f2c3c5626aebed9eaa79c18b3a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa9b5e79f1a990386191d264ea5e213bea7d4c937ca98ed792c77d22b765c235 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa9b5e79f1a990386191d264ea5e213bea7d4c937ca98ed792c77d22b765c235->enter($__internal_aa9b5e79f1a990386191d264ea5e213bea7d4c937ca98ed792c77d22b765c235_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        $__internal_b11b43559093c79d2edb4a5f4f0b2522f7a5bdb68f6c8ccb9ea4fcab858e657a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b11b43559093c79d2edb4a5f4f0b2522f7a5bdb68f6c8ccb9ea4fcab858e657a->enter($__internal_b11b43559093c79d2edb4a5f4f0b2522f7a5bdb68f6c8ccb9ea4fcab858e657a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo ($context["status_code"] ?? $this->getContext($context, "status_code"));
        echo " ";
        echo ($context["status_text"] ?? $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_aa9b5e79f1a990386191d264ea5e213bea7d4c937ca98ed792c77d22b765c235->leave($__internal_aa9b5e79f1a990386191d264ea5e213bea7d4c937ca98ed792c77d22b765c235_prof);

        
        $__internal_b11b43559093c79d2edb4a5f4f0b2522f7a5bdb68f6c8ccb9ea4fcab858e657a->leave($__internal_b11b43559093c79d2edb4a5f4f0b2522f7a5bdb68f6c8ccb9ea4fcab858e657a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "@Twig/Exception/error.txt.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.txt.twig");
    }
}
