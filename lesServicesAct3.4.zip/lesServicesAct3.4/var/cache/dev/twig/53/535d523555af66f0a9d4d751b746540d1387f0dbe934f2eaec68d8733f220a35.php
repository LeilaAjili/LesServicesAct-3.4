<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_3e74ffd0525fc3233db6002dbd32a6402605dad1b791f8bc0450f88f3fba53b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79308ef080bbf6cb11126a78139eaa7634e2e692073dbf5a54fb96b97c990732 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79308ef080bbf6cb11126a78139eaa7634e2e692073dbf5a54fb96b97c990732->enter($__internal_79308ef080bbf6cb11126a78139eaa7634e2e692073dbf5a54fb96b97c990732_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_82e56e2d2f7d196dbe3e4023eea8fee8131b83beb0f4515527313799371ece4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82e56e2d2f7d196dbe3e4023eea8fee8131b83beb0f4515527313799371ece4c->enter($__internal_82e56e2d2f7d196dbe3e4023eea8fee8131b83beb0f4515527313799371ece4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_79308ef080bbf6cb11126a78139eaa7634e2e692073dbf5a54fb96b97c990732->leave($__internal_79308ef080bbf6cb11126a78139eaa7634e2e692073dbf5a54fb96b97c990732_prof);

        
        $__internal_82e56e2d2f7d196dbe3e4023eea8fee8131b83beb0f4515527313799371ece4c->leave($__internal_82e56e2d2f7d196dbe3e4023eea8fee8131b83beb0f4515527313799371ece4c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
