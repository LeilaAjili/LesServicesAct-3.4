<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_b4fdf6e81c1de259c397928c1c967a3bc5f9edb4626489208ce211ea7ac52aec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b43ff5d796494a32d8629b89f6a64a97298745b4fd66eb04a7d4946b0b21486 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b43ff5d796494a32d8629b89f6a64a97298745b4fd66eb04a7d4946b0b21486->enter($__internal_4b43ff5d796494a32d8629b89f6a64a97298745b4fd66eb04a7d4946b0b21486_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_7314a8118916c48fc447236b4a70d75b689fa0633b7db6b9982be9de1c481f21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7314a8118916c48fc447236b4a70d75b689fa0633b7db6b9982be9de1c481f21->enter($__internal_7314a8118916c48fc447236b4a70d75b689fa0633b7db6b9982be9de1c481f21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_4b43ff5d796494a32d8629b89f6a64a97298745b4fd66eb04a7d4946b0b21486->leave($__internal_4b43ff5d796494a32d8629b89f6a64a97298745b4fd66eb04a7d4946b0b21486_prof);

        
        $__internal_7314a8118916c48fc447236b4a70d75b689fa0633b7db6b9982be9de1c481f21->leave($__internal_7314a8118916c48fc447236b4a70d75b689fa0633b7db6b9982be9de1c481f21_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
