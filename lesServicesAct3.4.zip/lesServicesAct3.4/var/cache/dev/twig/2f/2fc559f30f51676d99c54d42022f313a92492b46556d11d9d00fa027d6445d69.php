<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_458235b318b33071a538ce04e223129efa512954b323dab0b3a8914ad9e126ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10adde622f4a99472dfacd87adba24a8bc86d317d617e86eca494b93dabff4d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10adde622f4a99472dfacd87adba24a8bc86d317d617e86eca494b93dabff4d9->enter($__internal_10adde622f4a99472dfacd87adba24a8bc86d317d617e86eca494b93dabff4d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_9cd9a83be0e7f8b0c73badcc7e148f596bdd2ba796e618e2acaf1bcc8f2f2edd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cd9a83be0e7f8b0c73badcc7e148f596bdd2ba796e618e2acaf1bcc8f2f2edd->enter($__internal_9cd9a83be0e7f8b0c73badcc7e148f596bdd2ba796e618e2acaf1bcc8f2f2edd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_10adde622f4a99472dfacd87adba24a8bc86d317d617e86eca494b93dabff4d9->leave($__internal_10adde622f4a99472dfacd87adba24a8bc86d317d617e86eca494b93dabff4d9_prof);

        
        $__internal_9cd9a83be0e7f8b0c73badcc7e148f596bdd2ba796e618e2acaf1bcc8f2f2edd->leave($__internal_9cd9a83be0e7f8b0c73badcc7e148f596bdd2ba796e618e2acaf1bcc8f2f2edd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
