<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_458235b318b33071a538ce04e223129efa512954b323dab0b3a8914ad9e126ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf206324c7dbbf9fe37c81498fda94536757607f2a9d32b6bdb52c551118e5b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf206324c7dbbf9fe37c81498fda94536757607f2a9d32b6bdb52c551118e5b2->enter($__internal_bf206324c7dbbf9fe37c81498fda94536757607f2a9d32b6bdb52c551118e5b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_2d3af4822f2f4979cbac57d0ffb3c78369b572b458559c05192c0e5f73deda24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d3af4822f2f4979cbac57d0ffb3c78369b572b458559c05192c0e5f73deda24->enter($__internal_2d3af4822f2f4979cbac57d0ffb3c78369b572b458559c05192c0e5f73deda24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_bf206324c7dbbf9fe37c81498fda94536757607f2a9d32b6bdb52c551118e5b2->leave($__internal_bf206324c7dbbf9fe37c81498fda94536757607f2a9d32b6bdb52c551118e5b2_prof);

        
        $__internal_2d3af4822f2f4979cbac57d0ffb3c78369b572b458559c05192c0e5f73deda24->leave($__internal_2d3af4822f2f4979cbac57d0ffb3c78369b572b458559c05192c0e5f73deda24_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
