<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_057fd96f4c4f70718795b3438c121e5106fdf92611d5b2d0ecf51ec91f78baed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1730ccfaa92fa14967f4e2f778821dc7e220282880415a3f7875f6ad098be827 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1730ccfaa92fa14967f4e2f778821dc7e220282880415a3f7875f6ad098be827->enter($__internal_1730ccfaa92fa14967f4e2f778821dc7e220282880415a3f7875f6ad098be827_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_70ba1826fc1e339205cd0df45fcbdd7ddf87459a9544ee5aed948e0bd71d2fce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70ba1826fc1e339205cd0df45fcbdd7ddf87459a9544ee5aed948e0bd71d2fce->enter($__internal_70ba1826fc1e339205cd0df45fcbdd7ddf87459a9544ee5aed948e0bd71d2fce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_1730ccfaa92fa14967f4e2f778821dc7e220282880415a3f7875f6ad098be827->leave($__internal_1730ccfaa92fa14967f4e2f778821dc7e220282880415a3f7875f6ad098be827_prof);

        
        $__internal_70ba1826fc1e339205cd0df45fcbdd7ddf87459a9544ee5aed948e0bd71d2fce->leave($__internal_70ba1826fc1e339205cd0df45fcbdd7ddf87459a9544ee5aed948e0bd71d2fce_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
