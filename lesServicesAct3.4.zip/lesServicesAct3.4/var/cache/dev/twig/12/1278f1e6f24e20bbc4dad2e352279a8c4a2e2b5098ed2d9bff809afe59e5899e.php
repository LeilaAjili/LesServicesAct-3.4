<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_c8285102c09d5fce2d96c802385800449930b41363c746a9bc6777ef69ab3bd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_266299f902428f4e4ab3587d43911f18b337d881d9ef90339dc3bfde95458fa1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_266299f902428f4e4ab3587d43911f18b337d881d9ef90339dc3bfde95458fa1->enter($__internal_266299f902428f4e4ab3587d43911f18b337d881d9ef90339dc3bfde95458fa1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_d9a83c1f5e918ee537ce0b7f6ddb8d09918b7db9c991403b61eeafd96dbb6a8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9a83c1f5e918ee537ce0b7f6ddb8d09918b7db9c991403b61eeafd96dbb6a8c->enter($__internal_d9a83c1f5e918ee537ce0b7f6ddb8d09918b7db9c991403b61eeafd96dbb6a8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_266299f902428f4e4ab3587d43911f18b337d881d9ef90339dc3bfde95458fa1->leave($__internal_266299f902428f4e4ab3587d43911f18b337d881d9ef90339dc3bfde95458fa1_prof);

        
        $__internal_d9a83c1f5e918ee537ce0b7f6ddb8d09918b7db9c991403b61eeafd96dbb6a8c->leave($__internal_d9a83c1f5e918ee537ce0b7f6ddb8d09918b7db9c991403b61eeafd96dbb6a8c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.css.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
