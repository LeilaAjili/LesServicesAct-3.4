<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_82cfd82d9129f8a3b349e47dec1a796b0ce8bd3a21256b45d109633269475ab8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca4ecfda4a6525a3a124bdedd98ff9f1bc6dcbe21627ff980b80a9289bfcca0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca4ecfda4a6525a3a124bdedd98ff9f1bc6dcbe21627ff980b80a9289bfcca0f->enter($__internal_ca4ecfda4a6525a3a124bdedd98ff9f1bc6dcbe21627ff980b80a9289bfcca0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_695eff8ccfdce1d85eff9ccd95be2804332ecddf1d90ecb0e579cb42fcd91bdb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_695eff8ccfdce1d85eff9ccd95be2804332ecddf1d90ecb0e579cb42fcd91bdb->enter($__internal_695eff8ccfdce1d85eff9ccd95be2804332ecddf1d90ecb0e579cb42fcd91bdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_ca4ecfda4a6525a3a124bdedd98ff9f1bc6dcbe21627ff980b80a9289bfcca0f->leave($__internal_ca4ecfda4a6525a3a124bdedd98ff9f1bc6dcbe21627ff980b80a9289bfcca0f_prof);

        
        $__internal_695eff8ccfdce1d85eff9ccd95be2804332ecddf1d90ecb0e579cb42fcd91bdb->leave($__internal_695eff8ccfdce1d85eff9ccd95be2804332ecddf1d90ecb0e579cb42fcd91bdb_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.js.twig");
    }
}
