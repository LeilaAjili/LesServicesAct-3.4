<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_e1b17b672d538b6b91c8a060c36b7e27608c889b2144a6a4e8ee4ce83b0f1b9d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68408201fdaab7b1f06a84b182c4b17a4f1f26c4e5de729a60f91977dd702ac7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68408201fdaab7b1f06a84b182c4b17a4f1f26c4e5de729a60f91977dd702ac7->enter($__internal_68408201fdaab7b1f06a84b182c4b17a4f1f26c4e5de729a60f91977dd702ac7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_c091653893a9ab97cbc57f021307b18c8351b7983ae5c82bd256093595d5ad4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c091653893a9ab97cbc57f021307b18c8351b7983ae5c82bd256093595d5ad4a->enter($__internal_c091653893a9ab97cbc57f021307b18c8351b7983ae5c82bd256093595d5ad4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_68408201fdaab7b1f06a84b182c4b17a4f1f26c4e5de729a60f91977dd702ac7->leave($__internal_68408201fdaab7b1f06a84b182c4b17a4f1f26c4e5de729a60f91977dd702ac7_prof);

        
        $__internal_c091653893a9ab97cbc57f021307b18c8351b7983ae5c82bd256093595d5ad4a->leave($__internal_c091653893a9ab97cbc57f021307b18c8351b7983ae5c82bd256093595d5ad4a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
