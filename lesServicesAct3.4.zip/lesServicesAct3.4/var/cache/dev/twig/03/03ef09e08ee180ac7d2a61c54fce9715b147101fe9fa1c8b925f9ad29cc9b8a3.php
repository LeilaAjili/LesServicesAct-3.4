<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_6f31eb275bcfe2ff284ee4ce5a897064070e559597f9dbd071c2fb7b99842baf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_efb9a1ec083d59a2ad9b4ea39a66ab7d825f8a3243dd452faa94af3985766e26 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_efb9a1ec083d59a2ad9b4ea39a66ab7d825f8a3243dd452faa94af3985766e26->enter($__internal_efb9a1ec083d59a2ad9b4ea39a66ab7d825f8a3243dd452faa94af3985766e26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_c829649f2011f491791f784dc8eca933a9531dd815262c3ac91cb4d4a3d34626 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c829649f2011f491791f784dc8eca933a9531dd815262c3ac91cb4d4a3d34626->enter($__internal_c829649f2011f491791f784dc8eca933a9531dd815262c3ac91cb4d4a3d34626_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_efb9a1ec083d59a2ad9b4ea39a66ab7d825f8a3243dd452faa94af3985766e26->leave($__internal_efb9a1ec083d59a2ad9b4ea39a66ab7d825f8a3243dd452faa94af3985766e26_prof);

        
        $__internal_c829649f2011f491791f784dc8eca933a9531dd815262c3ac91cb4d4a3d34626->leave($__internal_c829649f2011f491791f784dc8eca933a9531dd815262c3ac91cb4d4a3d34626_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
