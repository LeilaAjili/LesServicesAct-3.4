<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_6f31eb275bcfe2ff284ee4ce5a897064070e559597f9dbd071c2fb7b99842baf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ffe990c10b1c4608b93580bed243712dd64b3f81669ec38b8fb09fdf027d42f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ffe990c10b1c4608b93580bed243712dd64b3f81669ec38b8fb09fdf027d42f->enter($__internal_8ffe990c10b1c4608b93580bed243712dd64b3f81669ec38b8fb09fdf027d42f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_1c0c9a7a7263928d775020c97dd1aaf4ca4276280c80355103f4273f8f6113cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c0c9a7a7263928d775020c97dd1aaf4ca4276280c80355103f4273f8f6113cb->enter($__internal_1c0c9a7a7263928d775020c97dd1aaf4ca4276280c80355103f4273f8f6113cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_8ffe990c10b1c4608b93580bed243712dd64b3f81669ec38b8fb09fdf027d42f->leave($__internal_8ffe990c10b1c4608b93580bed243712dd64b3f81669ec38b8fb09fdf027d42f_prof);

        
        $__internal_1c0c9a7a7263928d775020c97dd1aaf4ca4276280c80355103f4273f8f6113cb->leave($__internal_1c0c9a7a7263928d775020c97dd1aaf4ca4276280c80355103f4273f8f6113cb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
