<?php

/* base.html.twig */
class __TwigTemplate_35a788ca461558bba9038e4c3f84ff08bc8c4a644fa3eb1893a42b9f45e0624c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7a919a5ab0986b8d76ddd1ff979d9fc1637338dd31ac627e3ebd39e93aaede1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a7a919a5ab0986b8d76ddd1ff979d9fc1637338dd31ac627e3ebd39e93aaede1->enter($__internal_a7a919a5ab0986b8d76ddd1ff979d9fc1637338dd31ac627e3ebd39e93aaede1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_8ab516edacc6d440063f690748cc4da2f008cdd5ff222b042ff8b2d558bf3398 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ab516edacc6d440063f690748cc4da2f008cdd5ff222b042ff8b2d558bf3398->enter($__internal_8ab516edacc6d440063f690748cc4da2f008cdd5ff222b042ff8b2d558bf3398_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_a7a919a5ab0986b8d76ddd1ff979d9fc1637338dd31ac627e3ebd39e93aaede1->leave($__internal_a7a919a5ab0986b8d76ddd1ff979d9fc1637338dd31ac627e3ebd39e93aaede1_prof);

        
        $__internal_8ab516edacc6d440063f690748cc4da2f008cdd5ff222b042ff8b2d558bf3398->leave($__internal_8ab516edacc6d440063f690748cc4da2f008cdd5ff222b042ff8b2d558bf3398_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_65f511b1c6bf6ab5a87b12227f8a8b79f9fa473e9ce417930cee11e87d4d279d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65f511b1c6bf6ab5a87b12227f8a8b79f9fa473e9ce417930cee11e87d4d279d->enter($__internal_65f511b1c6bf6ab5a87b12227f8a8b79f9fa473e9ce417930cee11e87d4d279d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_a91ae7dff9bad636f4288ebb420a85f1b7cd4ab1219e180cae48b0c64a643600 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a91ae7dff9bad636f4288ebb420a85f1b7cd4ab1219e180cae48b0c64a643600->enter($__internal_a91ae7dff9bad636f4288ebb420a85f1b7cd4ab1219e180cae48b0c64a643600_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_a91ae7dff9bad636f4288ebb420a85f1b7cd4ab1219e180cae48b0c64a643600->leave($__internal_a91ae7dff9bad636f4288ebb420a85f1b7cd4ab1219e180cae48b0c64a643600_prof);

        
        $__internal_65f511b1c6bf6ab5a87b12227f8a8b79f9fa473e9ce417930cee11e87d4d279d->leave($__internal_65f511b1c6bf6ab5a87b12227f8a8b79f9fa473e9ce417930cee11e87d4d279d_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bf1b9d7bb34785d8415369be5717fb3f69b493bafe176755f85b9d947112e5b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf1b9d7bb34785d8415369be5717fb3f69b493bafe176755f85b9d947112e5b8->enter($__internal_bf1b9d7bb34785d8415369be5717fb3f69b493bafe176755f85b9d947112e5b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_438a70de256ccb1ded522555a12bd2c3473ee8caf40427eecd01b52d841c77e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_438a70de256ccb1ded522555a12bd2c3473ee8caf40427eecd01b52d841c77e5->enter($__internal_438a70de256ccb1ded522555a12bd2c3473ee8caf40427eecd01b52d841c77e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_438a70de256ccb1ded522555a12bd2c3473ee8caf40427eecd01b52d841c77e5->leave($__internal_438a70de256ccb1ded522555a12bd2c3473ee8caf40427eecd01b52d841c77e5_prof);

        
        $__internal_bf1b9d7bb34785d8415369be5717fb3f69b493bafe176755f85b9d947112e5b8->leave($__internal_bf1b9d7bb34785d8415369be5717fb3f69b493bafe176755f85b9d947112e5b8_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_bb5f1ddfda401b74934d9aa5e2035b31847b6bfb4937cffd6157f0e5db9901bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb5f1ddfda401b74934d9aa5e2035b31847b6bfb4937cffd6157f0e5db9901bc->enter($__internal_bb5f1ddfda401b74934d9aa5e2035b31847b6bfb4937cffd6157f0e5db9901bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9f8cf6a8966e2f2ae80e63323ba8613d4731996ed52a1e82259e5868dd601b7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f8cf6a8966e2f2ae80e63323ba8613d4731996ed52a1e82259e5868dd601b7c->enter($__internal_9f8cf6a8966e2f2ae80e63323ba8613d4731996ed52a1e82259e5868dd601b7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_9f8cf6a8966e2f2ae80e63323ba8613d4731996ed52a1e82259e5868dd601b7c->leave($__internal_9f8cf6a8966e2f2ae80e63323ba8613d4731996ed52a1e82259e5868dd601b7c_prof);

        
        $__internal_bb5f1ddfda401b74934d9aa5e2035b31847b6bfb4937cffd6157f0e5db9901bc->leave($__internal_bb5f1ddfda401b74934d9aa5e2035b31847b6bfb4937cffd6157f0e5db9901bc_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_cb07d54671dbeb7f9f956c39e5b80a5147ae540924c84747ab74f0b9fa6f90ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb07d54671dbeb7f9f956c39e5b80a5147ae540924c84747ab74f0b9fa6f90ea->enter($__internal_cb07d54671dbeb7f9f956c39e5b80a5147ae540924c84747ab74f0b9fa6f90ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_ece397c7f971fe67840990610b708916bc17d370097859faec360a8327c34374 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ece397c7f971fe67840990610b708916bc17d370097859faec360a8327c34374->enter($__internal_ece397c7f971fe67840990610b708916bc17d370097859faec360a8327c34374_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_ece397c7f971fe67840990610b708916bc17d370097859faec360a8327c34374->leave($__internal_ece397c7f971fe67840990610b708916bc17d370097859faec360a8327c34374_prof);

        
        $__internal_cb07d54671dbeb7f9f956c39e5b80a5147ae540924c84747ab74f0b9fa6f90ea->leave($__internal_cb07d54671dbeb7f9f956c39e5b80a5147ae540924c84747ab74f0b9fa6f90ea_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 11,  99 => 10,  82 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\app\\Resources\\views\\base.html.twig");
    }
}
