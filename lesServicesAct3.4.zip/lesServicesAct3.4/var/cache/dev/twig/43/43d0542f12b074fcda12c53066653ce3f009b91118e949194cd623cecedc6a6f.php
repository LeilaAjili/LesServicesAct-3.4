<?php

/* base.html.twig */
class __TwigTemplate_35a788ca461558bba9038e4c3f84ff08bc8c4a644fa3eb1893a42b9f45e0624c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dfb1d39b5afd27dd1f6ec4f19b8cf57414688b0841f49bcf20eece2ba7b98288 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dfb1d39b5afd27dd1f6ec4f19b8cf57414688b0841f49bcf20eece2ba7b98288->enter($__internal_dfb1d39b5afd27dd1f6ec4f19b8cf57414688b0841f49bcf20eece2ba7b98288_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_5dd07b7018aa80f4f449499ec7f9b2eecb0a6df2661d4b064a8eaeb8dd981e65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5dd07b7018aa80f4f449499ec7f9b2eecb0a6df2661d4b064a8eaeb8dd981e65->enter($__internal_5dd07b7018aa80f4f449499ec7f9b2eecb0a6df2661d4b064a8eaeb8dd981e65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_dfb1d39b5afd27dd1f6ec4f19b8cf57414688b0841f49bcf20eece2ba7b98288->leave($__internal_dfb1d39b5afd27dd1f6ec4f19b8cf57414688b0841f49bcf20eece2ba7b98288_prof);

        
        $__internal_5dd07b7018aa80f4f449499ec7f9b2eecb0a6df2661d4b064a8eaeb8dd981e65->leave($__internal_5dd07b7018aa80f4f449499ec7f9b2eecb0a6df2661d4b064a8eaeb8dd981e65_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_72b25f1ef72694b367c3f6c1006f5016f711815c15d3f691ebc5c808f3f0b104 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_72b25f1ef72694b367c3f6c1006f5016f711815c15d3f691ebc5c808f3f0b104->enter($__internal_72b25f1ef72694b367c3f6c1006f5016f711815c15d3f691ebc5c808f3f0b104_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_43dd92996cf1771aad5e20e3264437aaac2a864242a5aec5dc126f44ef650f5a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43dd92996cf1771aad5e20e3264437aaac2a864242a5aec5dc126f44ef650f5a->enter($__internal_43dd92996cf1771aad5e20e3264437aaac2a864242a5aec5dc126f44ef650f5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_43dd92996cf1771aad5e20e3264437aaac2a864242a5aec5dc126f44ef650f5a->leave($__internal_43dd92996cf1771aad5e20e3264437aaac2a864242a5aec5dc126f44ef650f5a_prof);

        
        $__internal_72b25f1ef72694b367c3f6c1006f5016f711815c15d3f691ebc5c808f3f0b104->leave($__internal_72b25f1ef72694b367c3f6c1006f5016f711815c15d3f691ebc5c808f3f0b104_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_979c6221a49662fde7bf8bba0a3e075526db88bd3f58b7635cdde4c19ca64544 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_979c6221a49662fde7bf8bba0a3e075526db88bd3f58b7635cdde4c19ca64544->enter($__internal_979c6221a49662fde7bf8bba0a3e075526db88bd3f58b7635cdde4c19ca64544_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_2252a5b57715a506ab72ca8e1ead5d1ee24f2492bd2eba9a23d690d378f087c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2252a5b57715a506ab72ca8e1ead5d1ee24f2492bd2eba9a23d690d378f087c7->enter($__internal_2252a5b57715a506ab72ca8e1ead5d1ee24f2492bd2eba9a23d690d378f087c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_2252a5b57715a506ab72ca8e1ead5d1ee24f2492bd2eba9a23d690d378f087c7->leave($__internal_2252a5b57715a506ab72ca8e1ead5d1ee24f2492bd2eba9a23d690d378f087c7_prof);

        
        $__internal_979c6221a49662fde7bf8bba0a3e075526db88bd3f58b7635cdde4c19ca64544->leave($__internal_979c6221a49662fde7bf8bba0a3e075526db88bd3f58b7635cdde4c19ca64544_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_aba8f17353f7a94b438c393d9f5988242f28615ee8763368deace6063a8feaff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aba8f17353f7a94b438c393d9f5988242f28615ee8763368deace6063a8feaff->enter($__internal_aba8f17353f7a94b438c393d9f5988242f28615ee8763368deace6063a8feaff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_56031639be5c828a35f4d80d21b7d2c561a15f86b184931530cf00b50f099b4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56031639be5c828a35f4d80d21b7d2c561a15f86b184931530cf00b50f099b4e->enter($__internal_56031639be5c828a35f4d80d21b7d2c561a15f86b184931530cf00b50f099b4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_56031639be5c828a35f4d80d21b7d2c561a15f86b184931530cf00b50f099b4e->leave($__internal_56031639be5c828a35f4d80d21b7d2c561a15f86b184931530cf00b50f099b4e_prof);

        
        $__internal_aba8f17353f7a94b438c393d9f5988242f28615ee8763368deace6063a8feaff->leave($__internal_aba8f17353f7a94b438c393d9f5988242f28615ee8763368deace6063a8feaff_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_00089eb8b15f695237f9f9f578425a3f55934dec0ba61deeb9bcaedea0994c36 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_00089eb8b15f695237f9f9f578425a3f55934dec0ba61deeb9bcaedea0994c36->enter($__internal_00089eb8b15f695237f9f9f578425a3f55934dec0ba61deeb9bcaedea0994c36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_3d5b8a56db10c80441a01f6516016bd15ed1d4b516af0949ed4b1cfdfab97613 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d5b8a56db10c80441a01f6516016bd15ed1d4b516af0949ed4b1cfdfab97613->enter($__internal_3d5b8a56db10c80441a01f6516016bd15ed1d4b516af0949ed4b1cfdfab97613_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_3d5b8a56db10c80441a01f6516016bd15ed1d4b516af0949ed4b1cfdfab97613->leave($__internal_3d5b8a56db10c80441a01f6516016bd15ed1d4b516af0949ed4b1cfdfab97613_prof);

        
        $__internal_00089eb8b15f695237f9f9f578425a3f55934dec0ba61deeb9bcaedea0994c36->leave($__internal_00089eb8b15f695237f9f9f578425a3f55934dec0ba61deeb9bcaedea0994c36_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 11,  99 => 10,  82 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\app\\Resources\\views\\base.html.twig");
    }
}
