<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_15cac7b37526b2c0b23674c767ddea7669c8a2217d38e99f500b014ea0bffba2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e425e71949f8792108c6b79dfe719563821ad3429ae452ce1b3669645c661ae3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e425e71949f8792108c6b79dfe719563821ad3429ae452ce1b3669645c661ae3->enter($__internal_e425e71949f8792108c6b79dfe719563821ad3429ae452ce1b3669645c661ae3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_d6f2125b638aa3a938c26ca3b1a36b78ccd9918a9e151d7d166de5afeeee6ef1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6f2125b638aa3a938c26ca3b1a36b78ccd9918a9e151d7d166de5afeeee6ef1->enter($__internal_d6f2125b638aa3a938c26ca3b1a36b78ccd9918a9e151d7d166de5afeeee6ef1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_e425e71949f8792108c6b79dfe719563821ad3429ae452ce1b3669645c661ae3->leave($__internal_e425e71949f8792108c6b79dfe719563821ad3429ae452ce1b3669645c661ae3_prof);

        
        $__internal_d6f2125b638aa3a938c26ca3b1a36b78ccd9918a9e151d7d166de5afeeee6ef1->leave($__internal_d6f2125b638aa3a938c26ca3b1a36b78ccd9918a9e151d7d166de5afeeee6ef1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
