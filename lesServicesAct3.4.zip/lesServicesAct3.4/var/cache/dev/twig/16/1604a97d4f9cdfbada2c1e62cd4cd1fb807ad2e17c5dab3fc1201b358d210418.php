<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_3096a43cef1ce004f01c5e29d7da068086df6a2e90f52d15664103c248ee1a7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7347cfa019afa1cebed00ecd2e4bbbbdabf59203fb594f173b6fb87e0babe9d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7347cfa019afa1cebed00ecd2e4bbbbdabf59203fb594f173b6fb87e0babe9d6->enter($__internal_7347cfa019afa1cebed00ecd2e4bbbbdabf59203fb594f173b6fb87e0babe9d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_59e60e2823bb9809d4498c13e537a06a8a3e9b8e1c3a11c34c6606a80dd4f0f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59e60e2823bb9809d4498c13e537a06a8a3e9b8e1c3a11c34c6606a80dd4f0f9->enter($__internal_59e60e2823bb9809d4498c13e537a06a8a3e9b8e1c3a11c34c6606a80dd4f0f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_7347cfa019afa1cebed00ecd2e4bbbbdabf59203fb594f173b6fb87e0babe9d6->leave($__internal_7347cfa019afa1cebed00ecd2e4bbbbdabf59203fb594f173b6fb87e0babe9d6_prof);

        
        $__internal_59e60e2823bb9809d4498c13e537a06a8a3e9b8e1c3a11c34c6606a80dd4f0f9->leave($__internal_59e60e2823bb9809d4498c13e537a06a8a3e9b8e1c3a11c34c6606a80dd4f0f9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
