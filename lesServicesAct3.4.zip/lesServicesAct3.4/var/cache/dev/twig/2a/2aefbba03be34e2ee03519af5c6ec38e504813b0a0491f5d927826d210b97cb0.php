<?php

/* bootstrap_4_layout.html.twig */
class __TwigTemplate_2a921476ece1769a3d9202de256c8afdb863f607da0e1b1d2fb0f36e9aaa78d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_base_layout.html.twig", "bootstrap_4_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_base_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'money_widget' => array($this, 'block_money_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'widget_attributes' => array($this, 'block_widget_attributes'),
                'button_widget' => array($this, 'block_button_widget'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'form_label' => array($this, 'block_form_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_564cc2048876f8d7a9776a04393522d95a78521eba6d84307a146d654162966a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_564cc2048876f8d7a9776a04393522d95a78521eba6d84307a146d654162966a->enter($__internal_564cc2048876f8d7a9776a04393522d95a78521eba6d84307a146d654162966a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_layout.html.twig"));

        $__internal_31883bad1bb28b9336e9d81c73422fb07bdbc860740ead51dade268aabd9aac9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31883bad1bb28b9336e9d81c73422fb07bdbc860740ead51dade268aabd9aac9->enter($__internal_31883bad1bb28b9336e9d81c73422fb07bdbc860740ead51dade268aabd9aac9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('money_widget', $context, $blocks);
        // line 12
        echo "
";
        // line 13
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 20
        echo "
";
        // line 21
        $this->displayBlock('date_widget', $context, $blocks);
        // line 28
        echo "
";
        // line 29
        $this->displayBlock('time_widget', $context, $blocks);
        // line 36
        echo "
";
        // line 37
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 44
        echo "
";
        // line 45
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 52
        echo "
";
        // line 53
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 60
        $this->displayBlock('widget_attributes', $context, $blocks);
        // line 67
        $this->displayBlock('button_widget', $context, $blocks);
        // line 71
        echo "
";
        // line 72
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 83
        echo "
";
        // line 84
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 95
        echo "
";
        // line 96
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 120
        echo "
";
        // line 122
        echo "
";
        // line 123
        $this->displayBlock('form_label', $context, $blocks);
        // line 132
        echo "
";
        // line 133
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 158
        echo "
";
        // line 160
        echo "
";
        // line 161
        $this->displayBlock('form_row', $context, $blocks);
        // line 171
        echo "
";
        // line 173
        echo "
";
        // line 174
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_564cc2048876f8d7a9776a04393522d95a78521eba6d84307a146d654162966a->leave($__internal_564cc2048876f8d7a9776a04393522d95a78521eba6d84307a146d654162966a_prof);

        
        $__internal_31883bad1bb28b9336e9d81c73422fb07bdbc860740ead51dade268aabd9aac9->leave($__internal_31883bad1bb28b9336e9d81c73422fb07bdbc860740ead51dade268aabd9aac9_prof);

    }

    // line 5
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_d9c484b79d0bac01ff2791460f882b164ef0e49e5d3eb5f206ac0c2d0f7e2720 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9c484b79d0bac01ff2791460f882b164ef0e49e5d3eb5f206ac0c2d0f7e2720->enter($__internal_d9c484b79d0bac01ff2791460f882b164ef0e49e5d3eb5f206ac0c2d0f7e2720_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_0cb527d16759e7a27edc81b0102653013133cf7c6409d3f89ea0fd7efe664d6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cb527d16759e7a27edc81b0102653013133cf7c6409d3f89ea0fd7efe664d6d->enter($__internal_0cb527d16759e7a27edc81b0102653013133cf7c6409d3f89ea0fd7efe664d6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 6
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            // line 7
            echo "        ";
            $context["group_class"] = " form-control is-invalid";
            // line 8
            echo "        ";
            $context["valid"] = true;
            // line 9
            echo "    ";
        }
        // line 10
        $this->displayParentBlock("money_widget", $context, $blocks);
        
        $__internal_0cb527d16759e7a27edc81b0102653013133cf7c6409d3f89ea0fd7efe664d6d->leave($__internal_0cb527d16759e7a27edc81b0102653013133cf7c6409d3f89ea0fd7efe664d6d_prof);

        
        $__internal_d9c484b79d0bac01ff2791460f882b164ef0e49e5d3eb5f206ac0c2d0f7e2720->leave($__internal_d9c484b79d0bac01ff2791460f882b164ef0e49e5d3eb5f206ac0c2d0f7e2720_prof);

    }

    // line 13
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_6d5ba37de6c351368fa39faa485bbf34527041a508c0241760f8901c9a7f5906 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d5ba37de6c351368fa39faa485bbf34527041a508c0241760f8901c9a7f5906->enter($__internal_6d5ba37de6c351368fa39faa485bbf34527041a508c0241760f8901c9a7f5906_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_25cf087fcb82ed1b2653ac51a12f1856bc7005716ecb3f06bcf3ae25d3976cb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25cf087fcb82ed1b2653ac51a12f1856bc7005716ecb3f06bcf3ae25d3976cb4->enter($__internal_25cf087fcb82ed1b2653ac51a12f1856bc7005716ecb3f06bcf3ae25d3976cb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 14
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 15
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 16
            $context["valid"] = true;
        }
        // line 18
        $this->displayParentBlock("datetime_widget", $context, $blocks);
        
        $__internal_25cf087fcb82ed1b2653ac51a12f1856bc7005716ecb3f06bcf3ae25d3976cb4->leave($__internal_25cf087fcb82ed1b2653ac51a12f1856bc7005716ecb3f06bcf3ae25d3976cb4_prof);

        
        $__internal_6d5ba37de6c351368fa39faa485bbf34527041a508c0241760f8901c9a7f5906->leave($__internal_6d5ba37de6c351368fa39faa485bbf34527041a508c0241760f8901c9a7f5906_prof);

    }

    // line 21
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_8b1cdd9a4cf1de8ec5d151f57b297aa88d897ed30a241b828dac0e2cde912593 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b1cdd9a4cf1de8ec5d151f57b297aa88d897ed30a241b828dac0e2cde912593->enter($__internal_8b1cdd9a4cf1de8ec5d151f57b297aa88d897ed30a241b828dac0e2cde912593_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_482ff8e3b1c1cea0a747f1edb6bd9ceaa56a1c4ff31205f1fe513e9e8d0b490b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_482ff8e3b1c1cea0a747f1edb6bd9ceaa56a1c4ff31205f1fe513e9e8d0b490b->enter($__internal_482ff8e3b1c1cea0a747f1edb6bd9ceaa56a1c4ff31205f1fe513e9e8d0b490b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 22
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 23
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 24
            $context["valid"] = true;
        }
        // line 26
        $this->displayParentBlock("date_widget", $context, $blocks);
        
        $__internal_482ff8e3b1c1cea0a747f1edb6bd9ceaa56a1c4ff31205f1fe513e9e8d0b490b->leave($__internal_482ff8e3b1c1cea0a747f1edb6bd9ceaa56a1c4ff31205f1fe513e9e8d0b490b_prof);

        
        $__internal_8b1cdd9a4cf1de8ec5d151f57b297aa88d897ed30a241b828dac0e2cde912593->leave($__internal_8b1cdd9a4cf1de8ec5d151f57b297aa88d897ed30a241b828dac0e2cde912593_prof);

    }

    // line 29
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_a4cbe44dbc8cc90d40243289fc04bbcb489508f2a9beb36ecd160d9ce71ff580 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a4cbe44dbc8cc90d40243289fc04bbcb489508f2a9beb36ecd160d9ce71ff580->enter($__internal_a4cbe44dbc8cc90d40243289fc04bbcb489508f2a9beb36ecd160d9ce71ff580_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_116064988884dc875a2620347ede1efe86443ed56e6709486e7cf4a922b4bbcb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_116064988884dc875a2620347ede1efe86443ed56e6709486e7cf4a922b4bbcb->enter($__internal_116064988884dc875a2620347ede1efe86443ed56e6709486e7cf4a922b4bbcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 30
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 31
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 32
            $context["valid"] = true;
        }
        // line 34
        $this->displayParentBlock("time_widget", $context, $blocks);
        
        $__internal_116064988884dc875a2620347ede1efe86443ed56e6709486e7cf4a922b4bbcb->leave($__internal_116064988884dc875a2620347ede1efe86443ed56e6709486e7cf4a922b4bbcb_prof);

        
        $__internal_a4cbe44dbc8cc90d40243289fc04bbcb489508f2a9beb36ecd160d9ce71ff580->leave($__internal_a4cbe44dbc8cc90d40243289fc04bbcb489508f2a9beb36ecd160d9ce71ff580_prof);

    }

    // line 37
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_cb145391df18f806ac4b025744ef8bb2408adf8e204cf5ca5fb5f8215ecceeae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb145391df18f806ac4b025744ef8bb2408adf8e204cf5ca5fb5f8215ecceeae->enter($__internal_cb145391df18f806ac4b025744ef8bb2408adf8e204cf5ca5fb5f8215ecceeae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_ca7024e73542d5d7374cbf86e0555e76a54faf7685f2e0315a7b20d6b9dff5d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca7024e73542d5d7374cbf86e0555e76a54faf7685f2e0315a7b20d6b9dff5d5->enter($__internal_ca7024e73542d5d7374cbf86e0555e76a54faf7685f2e0315a7b20d6b9dff5d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 38
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 39
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 40
            $context["valid"] = true;
        }
        // line 42
        $this->displayParentBlock("dateinterval_widget", $context, $blocks);
        
        $__internal_ca7024e73542d5d7374cbf86e0555e76a54faf7685f2e0315a7b20d6b9dff5d5->leave($__internal_ca7024e73542d5d7374cbf86e0555e76a54faf7685f2e0315a7b20d6b9dff5d5_prof);

        
        $__internal_cb145391df18f806ac4b025744ef8bb2408adf8e204cf5ca5fb5f8215ecceeae->leave($__internal_cb145391df18f806ac4b025744ef8bb2408adf8e204cf5ca5fb5f8215ecceeae_prof);

    }

    // line 45
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_d5532285d462067440ddccba8c8c08f7cecadaf8db6e70132d9be1a68d593c43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5532285d462067440ddccba8c8c08f7cecadaf8db6e70132d9be1a68d593c43->enter($__internal_d5532285d462067440ddccba8c8c08f7cecadaf8db6e70132d9be1a68d593c43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_f9c6c44d72794034dfb359a56b3e7180d3aeaefa5b0e6621f29436358386f04d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9c6c44d72794034dfb359a56b3e7180d3aeaefa5b0e6621f29436358386f04d->enter($__internal_f9c6c44d72794034dfb359a56b3e7180d3aeaefa5b0e6621f29436358386f04d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 46
        echo "<div class=\"input-group";
        echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
        echo "\">
        ";
        // line 47
        $context["valid"] = true;
        // line 48
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 49
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_f9c6c44d72794034dfb359a56b3e7180d3aeaefa5b0e6621f29436358386f04d->leave($__internal_f9c6c44d72794034dfb359a56b3e7180d3aeaefa5b0e6621f29436358386f04d_prof);

        
        $__internal_d5532285d462067440ddccba8c8c08f7cecadaf8db6e70132d9be1a68d593c43->leave($__internal_d5532285d462067440ddccba8c8c08f7cecadaf8db6e70132d9be1a68d593c43_prof);

    }

    // line 53
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_990cfbc032656fcc0e3d56531d268f44f6d05ac884bca1b00650eac97f694366 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_990cfbc032656fcc0e3d56531d268f44f6d05ac884bca1b00650eac97f694366->enter($__internal_990cfbc032656fcc0e3d56531d268f44f6d05ac884bca1b00650eac97f694366_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_bf9e9b0407c5c74a3a738aece63a4a77b83611b9a1b3247fb450a5ba39ef2f7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf9e9b0407c5c74a3a738aece63a4a77b83611b9a1b3247fb450a5ba39ef2f7c->enter($__internal_bf9e9b0407c5c74a3a738aece63a4a77b83611b9a1b3247fb450a5ba39ef2f7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 54
        if (( !array_key_exists("type", $context) || (($context["type"] ?? $this->getContext($context, "type")) != "hidden"))) {
            // line 55
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control") . (((((array_key_exists("type", $context)) ? (_twig_default_filter(($context["type"] ?? $this->getContext($context, "type")), "")) : ("")) == "file")) ? ("-file") : (""))))));
        }
        // line 57
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_bf9e9b0407c5c74a3a738aece63a4a77b83611b9a1b3247fb450a5ba39ef2f7c->leave($__internal_bf9e9b0407c5c74a3a738aece63a4a77b83611b9a1b3247fb450a5ba39ef2f7c_prof);

        
        $__internal_990cfbc032656fcc0e3d56531d268f44f6d05ac884bca1b00650eac97f694366->leave($__internal_990cfbc032656fcc0e3d56531d268f44f6d05ac884bca1b00650eac97f694366_prof);

    }

    // line 60
    public function block_widget_attributes($context, array $blocks = array())
    {
        $__internal_e673e2ff566aeb2e9f122a0ce15628d971f42301a0e6e3e550dd698b293a9fa2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e673e2ff566aeb2e9f122a0ce15628d971f42301a0e6e3e550dd698b293a9fa2->enter($__internal_e673e2ff566aeb2e9f122a0ce15628d971f42301a0e6e3e550dd698b293a9fa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "widget_attributes"));

        $__internal_691bd2e40eda5e7cb71aa0d4b62b1f9b7f19772243953842802b896855c051b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_691bd2e40eda5e7cb71aa0d4b62b1f9b7f19772243953842802b896855c051b4->enter($__internal_691bd2e40eda5e7cb71aa0d4b62b1f9b7f19772243953842802b896855c051b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "widget_attributes"));

        // line 61
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            // line 62
            echo "        ";
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 63
            echo "    ";
        }
        // line 64
        $this->displayParentBlock("widget_attributes", $context, $blocks);
        
        $__internal_691bd2e40eda5e7cb71aa0d4b62b1f9b7f19772243953842802b896855c051b4->leave($__internal_691bd2e40eda5e7cb71aa0d4b62b1f9b7f19772243953842802b896855c051b4_prof);

        
        $__internal_e673e2ff566aeb2e9f122a0ce15628d971f42301a0e6e3e550dd698b293a9fa2->leave($__internal_e673e2ff566aeb2e9f122a0ce15628d971f42301a0e6e3e550dd698b293a9fa2_prof);

    }

    // line 67
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_6a88623c69ddabab61d4bb6d5aa7c0d61ebfb478359ade4f8cc90c689a750508 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a88623c69ddabab61d4bb6d5aa7c0d61ebfb478359ade4f8cc90c689a750508->enter($__internal_6a88623c69ddabab61d4bb6d5aa7c0d61ebfb478359ade4f8cc90c689a750508_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_f387aeeb96bb47757bac9e102fe2efc4ea36c536fbfb859c6b942a39169c28cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f387aeeb96bb47757bac9e102fe2efc4ea36c536fbfb859c6b942a39169c28cb->enter($__internal_f387aeeb96bb47757bac9e102fe2efc4ea36c536fbfb859c6b942a39169c28cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 68
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-secondary")) : ("btn-secondary")) . " btn"))));
        // line 69
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_f387aeeb96bb47757bac9e102fe2efc4ea36c536fbfb859c6b942a39169c28cb->leave($__internal_f387aeeb96bb47757bac9e102fe2efc4ea36c536fbfb859c6b942a39169c28cb_prof);

        
        $__internal_6a88623c69ddabab61d4bb6d5aa7c0d61ebfb478359ade4f8cc90c689a750508->leave($__internal_6a88623c69ddabab61d4bb6d5aa7c0d61ebfb478359ade4f8cc90c689a750508_prof);

    }

    // line 72
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_4098f1b1fc84c00ba5d2c27a7ae1c50bbc139b2c9617168f83fba07eaedaad57 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4098f1b1fc84c00ba5d2c27a7ae1c50bbc139b2c9617168f83fba07eaedaad57->enter($__internal_4098f1b1fc84c00ba5d2c27a7ae1c50bbc139b2c9617168f83fba07eaedaad57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_748e9ad0d2ee3093faff0d82b58205c50bd97babe296dc3385e14cd53d05a951 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_748e9ad0d2ee3093faff0d82b58205c50bd97babe296dc3385e14cd53d05a951->enter($__internal_748e9ad0d2ee3093faff0d82b58205c50bd97babe296dc3385e14cd53d05a951_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 73
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 74
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-check-input"))));
        // line 75
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 76
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 78
            echo "<div class=\"form-check";
            echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
            echo "\">";
            // line 79
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 80
            echo "</div>";
        }
        
        $__internal_748e9ad0d2ee3093faff0d82b58205c50bd97babe296dc3385e14cd53d05a951->leave($__internal_748e9ad0d2ee3093faff0d82b58205c50bd97babe296dc3385e14cd53d05a951_prof);

        
        $__internal_4098f1b1fc84c00ba5d2c27a7ae1c50bbc139b2c9617168f83fba07eaedaad57->leave($__internal_4098f1b1fc84c00ba5d2c27a7ae1c50bbc139b2c9617168f83fba07eaedaad57_prof);

    }

    // line 84
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_a0388a14c5fd5bb98947b24dac0b52a219f908eea30bdb0546e85c4915dc31eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0388a14c5fd5bb98947b24dac0b52a219f908eea30bdb0546e85c4915dc31eb->enter($__internal_a0388a14c5fd5bb98947b24dac0b52a219f908eea30bdb0546e85c4915dc31eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_e668d3320f254e082adf4dfd024450fed9c71bbe5661002bdd833c3844960950 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e668d3320f254e082adf4dfd024450fed9c71bbe5661002bdd833c3844960950->enter($__internal_e668d3320f254e082adf4dfd024450fed9c71bbe5661002bdd833c3844960950_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 85
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 86
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-check-input"))));
        // line 87
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 88
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 90
            echo "<div class=\"form-check";
            echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
            echo "\">";
            // line 91
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 92
            echo "</div>";
        }
        
        $__internal_e668d3320f254e082adf4dfd024450fed9c71bbe5661002bdd833c3844960950->leave($__internal_e668d3320f254e082adf4dfd024450fed9c71bbe5661002bdd833c3844960950_prof);

        
        $__internal_a0388a14c5fd5bb98947b24dac0b52a219f908eea30bdb0546e85c4915dc31eb->leave($__internal_a0388a14c5fd5bb98947b24dac0b52a219f908eea30bdb0546e85c4915dc31eb_prof);

    }

    // line 96
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_9725bd9f6af5b1707ac026fcb587532337279168e96f50a3689527cf36c67786 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9725bd9f6af5b1707ac026fcb587532337279168e96f50a3689527cf36c67786->enter($__internal_9725bd9f6af5b1707ac026fcb587532337279168e96f50a3689527cf36c67786_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_856eed6bde13d064c657ee0aaebcb7b86e5cc0fed199ebbf2bcf7aa825487f13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_856eed6bde13d064c657ee0aaebcb7b86e5cc0fed199ebbf2bcf7aa825487f13->enter($__internal_856eed6bde13d064c657ee0aaebcb7b86e5cc0fed199ebbf2bcf7aa825487f13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 97
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 98
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 99
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 100
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 101
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain")), "valid" =>                 // line 102
($context["valid"] ?? $this->getContext($context, "valid"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 106
            if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
                // line 107
                $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            }
            // line 109
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 110
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 111
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 112
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 113
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain")), "valid" => true));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 117
            echo "</div>";
        }
        
        $__internal_856eed6bde13d064c657ee0aaebcb7b86e5cc0fed199ebbf2bcf7aa825487f13->leave($__internal_856eed6bde13d064c657ee0aaebcb7b86e5cc0fed199ebbf2bcf7aa825487f13_prof);

        
        $__internal_9725bd9f6af5b1707ac026fcb587532337279168e96f50a3689527cf36c67786->leave($__internal_9725bd9f6af5b1707ac026fcb587532337279168e96f50a3689527cf36c67786_prof);

    }

    // line 123
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_a61028316add19087adbb80ef1719136540a3cf34958dc783338ac7e044e29c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a61028316add19087adbb80ef1719136540a3cf34958dc783338ac7e044e29c9->enter($__internal_a61028316add19087adbb80ef1719136540a3cf34958dc783338ac7e044e29c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_3809d7fdaebe6b6f8a222dc438178d376b5a1dd062356fcab06264d32705f185 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3809d7fdaebe6b6f8a222dc438178d376b5a1dd062356fcab06264d32705f185->enter($__internal_3809d7fdaebe6b6f8a222dc438178d376b5a1dd062356fcab06264d32705f185_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 124
        if ((array_key_exists("compound", $context) && ($context["compound"] ?? $this->getContext($context, "compound")))) {
            // line 125
            $context["element"] = "legend";
            // line 126
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " col-form-legend"))));
        } else {
            // line 128
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " form-control-label"))));
        }
        // line 130
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_3809d7fdaebe6b6f8a222dc438178d376b5a1dd062356fcab06264d32705f185->leave($__internal_3809d7fdaebe6b6f8a222dc438178d376b5a1dd062356fcab06264d32705f185_prof);

        
        $__internal_a61028316add19087adbb80ef1719136540a3cf34958dc783338ac7e044e29c9->leave($__internal_a61028316add19087adbb80ef1719136540a3cf34958dc783338ac7e044e29c9_prof);

    }

    // line 133
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_d025660297bd221c7bda7dbc80accbd0c3f22ff67e22b7b9d561546685e7d949 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d025660297bd221c7bda7dbc80accbd0c3f22ff67e22b7b9d561546685e7d949->enter($__internal_d025660297bd221c7bda7dbc80accbd0c3f22ff67e22b7b9d561546685e7d949_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_c8e3aca8165efb9af2543587558a8e2398a9d58f8911a5909910c990591d0320 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8e3aca8165efb9af2543587558a8e2398a9d58f8911a5909910c990591d0320->enter($__internal_c8e3aca8165efb9af2543587558a8e2398a9d58f8911a5909910c990591d0320_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 135
        if (array_key_exists("widget", $context)) {
            // line 136
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " form-check-label"))));
            // line 137
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 138
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
            }
            // line 140
            if (array_key_exists("parent_label_class", $context)) {
                // line 141
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
            }
            // line 143
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 144
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 145
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 146
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 147
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 150
                    $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 153
            echo "<label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 154
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 155
            echo "</label>";
        }
        
        $__internal_c8e3aca8165efb9af2543587558a8e2398a9d58f8911a5909910c990591d0320->leave($__internal_c8e3aca8165efb9af2543587558a8e2398a9d58f8911a5909910c990591d0320_prof);

        
        $__internal_d025660297bd221c7bda7dbc80accbd0c3f22ff67e22b7b9d561546685e7d949->leave($__internal_d025660297bd221c7bda7dbc80accbd0c3f22ff67e22b7b9d561546685e7d949_prof);

    }

    // line 161
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_a22710897e8634902e1af69ccccc255f2e3df7ff32baebd0539568b8f8df7c07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a22710897e8634902e1af69ccccc255f2e3df7ff32baebd0539568b8f8df7c07->enter($__internal_a22710897e8634902e1af69ccccc255f2e3df7ff32baebd0539568b8f8df7c07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_b3db2d1a50601c5070ae1ee625b35ab9c15f444802aed31f3e6def04743ccb53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3db2d1a50601c5070ae1ee625b35ab9c15f444802aed31f3e6def04743ccb53->enter($__internal_b3db2d1a50601c5070ae1ee625b35ab9c15f444802aed31f3e6def04743ccb53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 162
        if ((array_key_exists("compound", $context) && ($context["compound"] ?? $this->getContext($context, "compound")))) {
            // line 163
            $context["element"] = "fieldset";
        }
        // line 165
        echo "<";
        echo twig_escape_filter($this->env, ((array_key_exists("element", $context)) ? (_twig_default_filter(($context["element"] ?? $this->getContext($context, "element")), "div")) : ("div")), "html", null, true);
        echo " class=\"form-group\">";
        // line 166
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 167
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 168
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 169
        echo "</";
        echo twig_escape_filter($this->env, ((array_key_exists("element", $context)) ? (_twig_default_filter(($context["element"] ?? $this->getContext($context, "element")), "div")) : ("div")), "html", null, true);
        echo ">";
        
        $__internal_b3db2d1a50601c5070ae1ee625b35ab9c15f444802aed31f3e6def04743ccb53->leave($__internal_b3db2d1a50601c5070ae1ee625b35ab9c15f444802aed31f3e6def04743ccb53_prof);

        
        $__internal_a22710897e8634902e1af69ccccc255f2e3df7ff32baebd0539568b8f8df7c07->leave($__internal_a22710897e8634902e1af69ccccc255f2e3df7ff32baebd0539568b8f8df7c07_prof);

    }

    // line 174
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_e378b8370e1920d514bc22be23e93b52aeff8cdf614622ca1f4a680841c1ba2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e378b8370e1920d514bc22be23e93b52aeff8cdf614622ca1f4a680841c1ba2c->enter($__internal_e378b8370e1920d514bc22be23e93b52aeff8cdf614622ca1f4a680841c1ba2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_5a3bd16d1713f2eda23ee411d60d64beb63a1c0c85453da913bc342af1ce2cb1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a3bd16d1713f2eda23ee411d60d64beb63a1c0c85453da913bc342af1ce2cb1->enter($__internal_5a3bd16d1713f2eda23ee411d60d64beb63a1c0c85453da913bc342af1ce2cb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 175
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 176
            echo "<div class=\"";
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "invalid-feedback";
            } else {
                echo "alert alert-danger";
            }
            echo "\">
        <ul class=\"list-unstyled mb-0\">";
            // line 178
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 179
                echo "<li>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 181
            echo "</ul>
    </div>";
        }
        
        $__internal_5a3bd16d1713f2eda23ee411d60d64beb63a1c0c85453da913bc342af1ce2cb1->leave($__internal_5a3bd16d1713f2eda23ee411d60d64beb63a1c0c85453da913bc342af1ce2cb1_prof);

        
        $__internal_e378b8370e1920d514bc22be23e93b52aeff8cdf614622ca1f4a680841c1ba2c->leave($__internal_e378b8370e1920d514bc22be23e93b52aeff8cdf614622ca1f4a680841c1ba2c_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_4_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  672 => 181,  664 => 179,  660 => 178,  651 => 176,  649 => 175,  640 => 174,  628 => 169,  626 => 168,  624 => 167,  622 => 166,  618 => 165,  615 => 163,  613 => 162,  604 => 161,  593 => 155,  589 => 154,  574 => 153,  570 => 150,  567 => 147,  566 => 146,  565 => 145,  563 => 144,  561 => 143,  558 => 141,  556 => 140,  553 => 138,  551 => 137,  549 => 136,  547 => 135,  538 => 133,  528 => 130,  525 => 128,  522 => 126,  520 => 125,  518 => 124,  509 => 123,  498 => 117,  492 => 113,  491 => 112,  490 => 111,  486 => 110,  482 => 109,  479 => 107,  477 => 106,  470 => 102,  469 => 101,  468 => 100,  467 => 99,  463 => 98,  461 => 97,  452 => 96,  441 => 92,  439 => 91,  435 => 90,  432 => 88,  430 => 87,  428 => 86,  426 => 85,  417 => 84,  406 => 80,  404 => 79,  400 => 78,  397 => 76,  395 => 75,  393 => 74,  391 => 73,  382 => 72,  372 => 69,  370 => 68,  361 => 67,  351 => 64,  348 => 63,  345 => 62,  343 => 61,  334 => 60,  324 => 57,  321 => 55,  319 => 54,  310 => 53,  299 => 49,  297 => 48,  295 => 47,  290 => 46,  281 => 45,  271 => 42,  268 => 40,  266 => 39,  264 => 38,  255 => 37,  245 => 34,  242 => 32,  240 => 31,  238 => 30,  229 => 29,  219 => 26,  216 => 24,  214 => 23,  212 => 22,  203 => 21,  193 => 18,  190 => 16,  188 => 15,  186 => 14,  177 => 13,  167 => 10,  164 => 9,  161 => 8,  158 => 7,  156 => 6,  147 => 5,  137 => 174,  134 => 173,  131 => 171,  129 => 161,  126 => 160,  123 => 158,  121 => 133,  118 => 132,  116 => 123,  113 => 122,  110 => 120,  108 => 96,  105 => 95,  103 => 84,  100 => 83,  98 => 72,  95 => 71,  93 => 67,  91 => 60,  89 => 53,  86 => 52,  84 => 45,  81 => 44,  79 => 37,  76 => 36,  74 => 29,  71 => 28,  69 => 21,  66 => 20,  64 => 13,  61 => 12,  59 => 5,  56 => 4,  53 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_base_layout.html.twig\" %}

{# Widgets #}

{% block money_widget -%}
    {% if not valid %}
        {% set group_class = ' form-control is-invalid' %}
        {% set valid = true %}
    {% endif %}
    {{- parent() -}}
{%- endblock money_widget %}

{% block datetime_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock date_widget %}

{% block time_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock time_widget %}

{% block dateinterval_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock dateinterval_widget %}

{% block percent_widget -%}
    <div class=\"input-group{{ not valid ? ' form-control is-invalid' }}\">
        {% set valid = true %}
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block form_widget_simple -%}
    {% if type is not defined or type != 'hidden' %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control' ~ (type|default('') == 'file' ? '-file' : ''))|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{%- block widget_attributes -%}
    {%- if not valid %}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) %}
    {% endif -%}
    {{ parent() }}
{%- endblock widget_attributes -%}

{% block button_widget -%}
    {%- set attr = attr|merge({class: (attr.class|default('btn-secondary') ~ ' btn')|trim}) -%}
    {{- parent() -}}
{%- endblock button_widget %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-check-input')|trim}) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"form-check{{ not valid ? ' form-control is-invalid' }}\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-check-input')|trim}) -%}
    {%- if 'radio-inline' in parent_label_class -%}
        {{- form_label(form, null, { widget: parent() }) -}}
    {%- else -%}
        <div class=\"form-check{{ not valid ? ' form-control is-invalid' }}\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock radio_widget %}

{% block choice_widget_expanded -%}
    {% if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
                valid: valid,
            }) -}}
        {% endfor -%}
    {%- else -%}
        {%- if not valid -%}
            {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) %}
        {%- endif -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                    valid: true,
                }) -}}
            {% endfor -%}
        </div>
    {%- endif %}
{%- endblock choice_widget_expanded %}

{# Labels #}

{% block form_label -%}
    {%- if compound is defined and compound -%}
        {%- set element = 'legend' -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' col-form-legend')|trim}) -%}
    {%- else -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' form-control-label')|trim}) -%}
    {%- endif -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block checkbox_radio_label -%}
    {#- Do not display the label if widget is not defined in order to prevent double label rendering -#}
    {%- if widget is defined -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' form-check-label')|trim}) -%}
        {%- if required -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) -%}
        {%- endif -%}
        {%- if parent_label_class is defined -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) -%}
        {%- endif -%}
        {%- if label is not same as(false) and label is empty -%}
            {%- if label_format is not empty -%}
                {%- set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) -%}
            {%- else -%}
                {%- set label = name|humanize -%}
            {%- endif -%}
        {%- endif -%}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {%- endif -%}
{%- endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    {%- if compound is defined and compound -%}
        {%- set element = 'fieldset' -%}
    {%- endif -%}
    <{{ element|default('div') }} class=\"form-group\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </{{ element|default('div') }}>
{%- endblock form_row %}

{# Errors #}

{% block form_errors -%}
    {%- if errors|length > 0 -%}
    <div class=\"{% if form.parent %}invalid-feedback{% else %}alert alert-danger{% endif %}\">
        <ul class=\"list-unstyled mb-0\">
            {%- for error in errors -%}
                <li>{{ error.message }}</li>
            {%- endfor -%}
        </ul>
    </div>
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_4_layout.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_4_layout.html.twig");
    }
}
