<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_4636f147e5f61754611d1e3378dfab98d1aae296d339b07bbe1163ced9283ca8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_65bfc8bd26779d8508886b935fae06f01d6b8c86aaa73e51c7b1c1c9e6b7b76f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65bfc8bd26779d8508886b935fae06f01d6b8c86aaa73e51c7b1c1c9e6b7b76f->enter($__internal_65bfc8bd26779d8508886b935fae06f01d6b8c86aaa73e51c7b1c1c9e6b7b76f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_e448fe85b7f90121def6984404b7dfe6604e82fd0d12e4f13775c58d08e1dc3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e448fe85b7f90121def6984404b7dfe6604e82fd0d12e4f13775c58d08e1dc3e->enter($__internal_e448fe85b7f90121def6984404b7dfe6604e82fd0d12e4f13775c58d08e1dc3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_65bfc8bd26779d8508886b935fae06f01d6b8c86aaa73e51c7b1c1c9e6b7b76f->leave($__internal_65bfc8bd26779d8508886b935fae06f01d6b8c86aaa73e51c7b1c1c9e6b7b76f_prof);

        
        $__internal_e448fe85b7f90121def6984404b7dfe6604e82fd0d12e4f13775c58d08e1dc3e->leave($__internal_e448fe85b7f90121def6984404b7dfe6604e82fd0d12e4f13775c58d08e1dc3e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
