<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_0a05875b8dcd1905ced758d797c16d5bd35942831022184846e48226124ee1f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fb62bc762bf7c42c23a2324a63d6b1ec1be8ff4b31c51950896a8433651eabc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fb62bc762bf7c42c23a2324a63d6b1ec1be8ff4b31c51950896a8433651eabc->enter($__internal_2fb62bc762bf7c42c23a2324a63d6b1ec1be8ff4b31c51950896a8433651eabc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_00eed7594be4eeb4d7d4224f0945783e608c6ec99f61bc4d72260fd8ce26df50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00eed7594be4eeb4d7d4224f0945783e608c6ec99f61bc4d72260fd8ce26df50->enter($__internal_00eed7594be4eeb4d7d4224f0945783e608c6ec99f61bc4d72260fd8ce26df50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_2fb62bc762bf7c42c23a2324a63d6b1ec1be8ff4b31c51950896a8433651eabc->leave($__internal_2fb62bc762bf7c42c23a2324a63d6b1ec1be8ff4b31c51950896a8433651eabc_prof);

        
        $__internal_00eed7594be4eeb4d7d4224f0945783e608c6ec99f61bc4d72260fd8ce26df50->leave($__internal_00eed7594be4eeb4d7d4224f0945783e608c6ec99f61bc4d72260fd8ce26df50_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\LesServices\\lesServicesAct3.4\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form.html.php");
    }
}
